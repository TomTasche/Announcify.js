var SETTINGS = new Store("settings", {
    "rate": 1,
    "volume": 1,
    "interval": 60
});